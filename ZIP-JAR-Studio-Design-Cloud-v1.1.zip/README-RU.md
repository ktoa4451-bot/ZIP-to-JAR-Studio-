# ZIP-JAR Studio — Android source

Android WebView UI for launching a real Gradle build of a mod project ZIP.

## Android APK build

Use Java 17 and Android SDK 35. Open the project in Android Studio or run the repository's Android GitHub Actions workflow. The launcher label is `ZIP-JAR Studio` and the app icon is in `app/src/main/res/drawable/ic_launcher.xml`.

## Mode 1: Termux (local)

1. Install Termux from a trusted source and enable its **Run commands** permission for external apps.
2. In Termux run `termux-setup-storage` then `pkg update && pkg install openjdk-21 gradle unzip`.
3. Select the mod project's ZIP in the app and choose Termux mode.
4. Inspect the actual Gradle log in Termux. Successful outputs are copied to `Download/ZIP-JAR-Studio/output/`.

The app does not fake a successful build. A JAR is only produced if Gradle actually succeeds and creates one under `build/libs`.

## Mode 2: GitHub Actions (cloud)

The included `.github/workflows/build-mod.yml` builds the file `input/project.zip` on a GitHub-hosted runner using Java 21. To use it:

1. Create or open your own GitHub repository.
2. Upload this Android source/project files and the workflow file.
3. Create the `input` folder and upload the mod project ZIP as `input/project.zip`.
4. Open **Actions → Build Fabric JAR → Run workflow**.
5. After success, download the `fabric-mod-jar` artifact from that workflow run.

The APK does not upload source code to GitHub automatically. You must explicitly upload the ZIP to your repository. Treat private source code and repository access tokens carefully; no personal access token is embedded in this app.

## Common build failures

- The ZIP must contain a Gradle project (`settings.gradle(.kts)`, `build.gradle(.kts)` or a Gradle wrapper).
- Java, Gradle and Fabric Loom versions must be compatible with the mod project.
- Dependencies need access to their Maven repositories.
- A green APK workflow only confirms that the Android app compiled; it does not guarantee every mod project will compile.
- If Gradle fails, inspect the final error lines in the Actions log or Termux. The app cannot repair errors in the mod's source code automatically.
