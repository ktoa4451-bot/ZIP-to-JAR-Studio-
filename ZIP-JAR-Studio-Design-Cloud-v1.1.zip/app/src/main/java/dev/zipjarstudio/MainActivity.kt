package dev.zipjarstudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var archiveName: String = ""
    private val pickZip = 4102
    private val sharedDir get() = File("/storage/emulated/0/Download/ZIP-JAR-Studio")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (android.os.Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                val settingsIntent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(settingsIntent)
            } catch (_: Exception) {
                Toast.makeText(this, "Разреши доступ ко всем файлам, чтобы обмениваться архивом с Termux.", Toast.LENGTH_LONG).show()
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun chooseZip() { runOnUiThread {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            }
            startActivityForResult(i, pickZip)
        } }

        @JavascriptInterface fun launchBuild() { runOnUiThread {
            val input = File(sharedDir, "input.zip")
            if (!input.exists()) { send("error", "Сначала выбери ZIP-архив."); return@runOnUiThread }
            val termux = packageManager.getLaunchIntentForPackage("com.termux")
            if (termux == null) { send("error", "Termux не установлен. Установи Termux и настрой JDK 21 + Gradle по инструкции."); return@runOnUiThread }
            val command = File(sharedDir, "build.sh")
            if (!command.exists()) { send("error", "Скрипт сборки не найден. Повторно выбери ZIP."); return@runOnUiThread }
            try {
                val run = Intent("com.termux.RUN_COMMAND").apply {
                    setClassName("com.termux", "com.termux.app.RunCommandService")
                    putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                    putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", "bash '${
                        command.absolutePath.replace("'", "'\\''")
                    }"))
                    putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                    putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
                }
                startService(run)
                send("info", "Команда передана Termux. Сборка идёт локально; открой Termux, чтобы смотреть настоящий журнал Gradle. После успеха JAR появится в Download/ZIP-JAR-Studio/output/.")
            } catch (e: Exception) {
                send("error", "Не удалось запустить Termux: ${e.message}. Проверь разрешение запуска команд внешними приложениями.")
            }
        } }

        @JavascriptInterface fun openGithubActions() { runOnUiThread {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/actions")))
            } catch (e: Exception) {
                send("error", "Не удалось открыть GitHub: ${e.message}")
            }
        } }

        @JavascriptInterface fun getStatus(): String =
            if (File(sharedDir, "input.zip").exists()) "ZIP готов: ${File(sharedDir, "input.zip").length()} байт" else "Архив пока не выбран"

        private fun send(kind: String, message: String) {
            val safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
            web.evaluateJavascript("window.onNativeMessage('$kind','$safe')", null)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickZip || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            sharedDir.mkdirs()
            val input = File(sharedDir, "input.zip")
            contentResolver.openInputStream(uri).use { source ->
                requireNotNull(source) { "Не удалось открыть выбранный файл" }
                FileOutputStream(input).use { out -> source.copyTo(out) }
            }
            val scan = inspectZip(input)
            if (!scan.first) {
                input.delete()
                web.evaluateJavascript("window.onNativeMessage('error','ZIP не похож на Gradle-проект: не найден build.gradle или build.gradle.kts.')", null)
            } else {
                writeBuildScript()
                val msg = "ZIP загружен: ${input.length()} байт. ${scan.second}"
                val safe = msg.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
                web.evaluateJavascript("window.onNativeMessage('success','$safe')", null)
            }
        } catch (e: Exception) {
            web.evaluateJavascript("window.onNativeMessage('error','Ошибка чтения ZIP: ${e.message?.replace("'", "") ?: "неизвестная ошибка"}')", null)
        }
    }

    private fun inspectZip(file: File): Pair<Boolean, String> {
        var gradle = false
        var fabric = false
        var entries = 0
        ZipInputStream(file.inputStream().buffered()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                entries++
                val name = entry.name.replace('\\', '/')
                if (name.endsWith("build.gradle") || name.endsWith("build.gradle.kts")) gradle = true
                if (name.endsWith("fabric.mod.json")) fabric = true
                zis.closeEntry()
            }
        }
        return Pair(gradle, "Файлов в архиве: $entries. fabric.mod.json: ${if (fabric) "найден" else "не найден"}")
    }

    private fun writeBuildScript() {
        val script = """#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
BASE="/storage/emulated/0/Download/ZIP-JAR-Studio"
WORK="@DOLLAR@HOME/zip-jar-studio-work"
mkdir -p "@DOLLAR@BASE/output"
rm -rf "@DOLLAR@WORK"
mkdir -p "@DOLLAR@WORK/project"
echo "=== ZIP → JAR Studio: local Gradle build ==="
command -v java >/dev/null || { echo "ERROR: Java не найдена. Выполни: pkg install openjdk-21"; exit 10; }
command -v unzip >/dev/null || { echo "ERROR: unzip не найден. Выполни: pkg install unzip"; exit 11; }
unzip -q "@DOLLAR@BASE/input.zip" -d "@DOLLAR@WORK/project"
ROOT="@DOLLAR@WORK/project"
# If the ZIP contains one wrapper directory, build from that directory.
for f in "@DOLLAR@ROOT/gradlew" "@DOLLAR@ROOT/build.gradle" "@DOLLAR@ROOT/build.gradle.kts"; do
  if [ -f "@DOLLAR@f" ]; then break; fi
done
if [ ! -f "@DOLLAR@ROOT/build.gradle" ] && [ ! -f "@DOLLAR@ROOT/build.gradle.kts" ] && [ ! -f "@DOLLAR@ROOT/gradlew" ]; then
  found="@DOLLAR@(find "@DOLLAR@ROOT" -maxdepth 4 \( -name build.gradle -o -name build.gradle.kts -o -name gradlew \) -print -quit)"
  [ -n "@DOLLAR@found" ] || { echo "ERROR: Gradle project files not found"; exit 12; }
  ROOT="@DOLLAR@(dirname "@DOLLAR@found")"
  # If found is a module's build file, walk upward to settings.gradle or wrapper.
  while [ "@DOLLAR@ROOT" != "@DOLLAR@WORK/project" ] && [ ! -f "@DOLLAR@ROOT/settings.gradle" ] && [ ! -f "@DOLLAR@ROOT/settings.gradle.kts" ] && [ ! -f "@DOLLAR@ROOT/gradlew" ]; do ROOT="@DOLLAR@(dirname "@DOLLAR@ROOT")"; done
fi
cd "@DOLLAR@ROOT"
echo "Project root: @DOLLAR@ROOT"
if [ -f ./gradlew ]; then
  chmod +x ./gradlew
  ./gradlew --no-daemon build
elif command -v gradle >/dev/null; then
  gradle --no-daemon build
else
  echo "ERROR: Gradle не найден. Выполни: pkg install gradle"
  exit 13
fi
echo "=== Searching for actual JAR outputs ==="
mapfile -t jars < <(find . -type f -path '*/build/libs/*.jar' ! -name '*-sources.jar' ! -name '*-javadoc.jar')
if [ "@DOLLAR@{#jars[@]}" -eq 0 ]; then echo "ERROR: Gradle завершился, но JAR в build/libs не найден."; exit 14; fi
for j in "@DOLLAR@{jars[@]}"; do
  cp "@DOLLAR@j" "@DOLLAR@BASE/output/@DOLLAR@(basename "@DOLLAR@j")"
  echo "JAR: @DOLLAR@BASE/output/@DOLLAR@(basename "@DOLLAR@j")"
done
echo "BUILD SUCCESS: реальные JAR-файлы скопированы в @DOLLAR@BASE/output"
""".replace("@DOLLAR@", "\$")
        sharedDir.mkdirs()
        File(sharedDir, "build.sh").writeText(script)
    }
}
