Put your mod archive here and name it project.zip.
